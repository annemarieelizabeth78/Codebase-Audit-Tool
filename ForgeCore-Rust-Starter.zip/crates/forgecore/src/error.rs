use std::path::PathBuf;

#[derive(Debug, thiserror::Error)]
pub enum ForgeError {
    #[error("path does not exist: {0}")]
    MissingPath(PathBuf),
    #[error("path is not a directory: {0}")]
    NotDirectory(PathBuf),
    #[error("filesystem error at {path}: {source}")]
    Io {
        path: PathBuf,
        #[source]
        source: std::io::Error,
    },
    #[error("serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
}

pub type Result<T> = std::result::Result<T, ForgeError>;
