use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::path::PathBuf;
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisRequest {
    pub root: PathBuf,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisReport {
    pub analysis_id: Uuid,
    pub root: PathBuf,
    pub files_scanned: usize,
    pub total_bytes: u64,
    pub total_lines: u64,
    pub extensions: BTreeMap<String, usize>,
    pub warnings: Vec<String>,
}
