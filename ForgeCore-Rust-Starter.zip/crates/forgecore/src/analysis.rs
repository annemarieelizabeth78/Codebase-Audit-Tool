use crate::{ForgeError, Result};
use serde::{Deserialize, Serialize};
use std::{
    collections::BTreeMap,
    fs,
    path::{Path, PathBuf},
};
use uuid::Uuid;

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalyzerConfig {
    pub include_hidden: bool,
    pub max_file_bytes: u64,
    pub ignored_directories: Vec<String>,
}

impl Default for AnalyzerConfig {
    fn default() -> Self {
        Self {
            include_hidden: false,
            max_file_bytes: 2 * 1024 * 1024,
            ignored_directories: vec![
                ".git".into(), "target".into(), "node_modules".into(),
                "vendor".into(), "dist".into(),
            ],
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AnalysisReport {
    pub analysis_id: Uuid,
    pub root: PathBuf,
    pub files_scanned: usize,
    pub total_bytes: u64,
    pub total_lines: u64,
    pub extensions: BTreeMap<String, usize>,
    pub warnings: Vec<String>,
}

pub fn analyze_directory(root: impl AsRef<Path>, config: &AnalyzerConfig) -> Result<AnalysisReport> {
    let root = root.as_ref();
    if !root.exists() {
        return Err(ForgeError::MissingPath(root.to_path_buf()));
    }
    if !root.is_dir() {
        return Err(ForgeError::NotDirectory(root.to_path_buf()));
    }

    let mut report = AnalysisReport {
        analysis_id: Uuid::new_v4(),
        root: root.canonicalize().unwrap_or_else(|_| root.to_path_buf()),
        files_scanned: 0,
        total_bytes: 0,
        total_lines: 0,
        extensions: BTreeMap::new(),
        warnings: Vec::new(),
    };
    visit(root, config, &mut report)?;
    Ok(report)
}

fn visit(path: &Path, config: &AnalyzerConfig, report: &mut AnalysisReport) -> Result<()> {
    let entries = fs::read_dir(path).map_err(|source| ForgeError::Io {
        path: path.to_path_buf(), source
    })?;

    for entry in entries {
        let entry = entry.map_err(|source| ForgeError::Io {
            path: path.to_path_buf(), source
        })?;
        let item = entry.path();
        let name = entry.file_name().to_string_lossy().to_string();

        if !config.include_hidden && name.starts_with('.') {
            continue;
        }
        let metadata = match entry.metadata() {
            Ok(value) => value,
            Err(error) => {
                report.warnings.push(format!("Could not read metadata for {}: {error}", item.display()));
                continue;
            }
        };

        if metadata.is_dir() {
            if !config.ignored_directories.iter().any(|v| v == &name) {
                visit(&item, config, report)?;
            }
            continue;
        }
        if !metadata.is_file() || metadata.len() > config.max_file_bytes {
            continue;
        }

        let bytes = match fs::read(&item) {
            Ok(value) => value,
            Err(error) => {
                report.warnings.push(format!("Could not read {}: {error}", item.display()));
                continue;
            }
        };
        // Count lines only for valid UTF-8 text; binary files still contribute to byte totals.
        report.files_scanned += 1;
        report.total_bytes += bytes.len() as u64;
        if let Ok(contents) = std::str::from_utf8(&bytes) {
            report.total_lines += contents.lines().count() as u64;
        }
        let extension = item.extension()
            .and_then(|v| v.to_str())
            .unwrap_or("[no extension]")
            .to_ascii_lowercase();
        *report.extensions.entry(extension).or_insert(0) += 1;
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use tempfile::tempdir;

    #[test]
    fn counts_files_lines_and_extensions() {
        let dir = tempdir().unwrap();
        fs::create_dir(dir.path().join("src")).unwrap();
        fs::write(dir.path().join("src/main.rs"), "fn main() {\\n}\\n").unwrap();
        fs::write(dir.path().join("README.md"), "hello\\nworld\\n").unwrap();

        let report = analyze_directory(dir.path(), &AnalyzerConfig::default()).unwrap();
        assert_eq!(report.files_scanned, 2);
        assert_eq!(report.total_lines, 4);
        assert_eq!(report.extensions.get("rs"), Some(&1));
        assert_eq!(report.extensions.get("md"), Some(&1));
    }

    #[test]
    fn ignores_hidden_and_build_directories() {
        let dir = tempdir().unwrap();
        fs::create_dir(dir.path().join(".git")).unwrap();
        fs::create_dir(dir.path().join("target")).unwrap();
        fs::write(dir.path().join(".secret"), "hidden").unwrap();
        fs::write(dir.path().join("target/cache.rs"), "ignored").unwrap();
        fs::write(dir.path().join("visible.rs"), "visible").unwrap();

        let report = analyze_directory(dir.path(), &AnalyzerConfig::default()).unwrap();
        assert_eq!(report.files_scanned, 1);
    }

    #[test]
    fn rejects_missing_path() {
        let result = analyze_directory("/this/path/should/not/exist/forgecore", &AnalyzerConfig::default());
        assert!(matches!(result, Err(ForgeError::MissingPath(_))));
    }
}
