use axum::{extract::State, http::StatusCode, routing::{get, post}, Json, Router};
use clap::{Parser, Subcommand};
use forgecore::{analyze_directory, AnalysisReport, AnalyzerConfig};
use serde::Deserialize;
use std::{net::SocketAddr, path::PathBuf, sync::Arc};

#[derive(Parser)]
#[command(name = "forgecore", about = "Software repository intelligence platform")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    Inspect { path: PathBuf },
    Serve {
        #[arg(long, default_value = "127.0.0.1")]
        host: String,
        #[arg(long, default_value_t = 8080)]
        port: u16,
    },
}

#[derive(Clone)]
struct AppState {
    config: Arc<AnalyzerConfig>,
}

#[derive(Deserialize)]
struct InspectBody {
    root: PathBuf,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(tracing_subscriber::EnvFilter::from_default_env())
        .init();

    match Cli::parse().command {
        Commands::Inspect { path } => {
            let report = analyze_directory(path, &AnalyzerConfig::default())?;
            println!("{}", serde_json::to_string_pretty(&report)?);
        }
        Commands::Serve { host, port } => {
            let address: SocketAddr = format!("{host}:{port}").parse()?;
            let state = AppState { config: Arc::new(AnalyzerConfig::default()) };
            let app = Router::new()
                .route("/health", get(health))
                .route("/v1/analysis", post(analyze))
                .with_state(state);
            let listener = tokio::net::TcpListener::bind(address).await?;
            tracing::info!("ForgeCore listening on {}", listener.local_addr()?);
            axum::serve(listener, app).await?;
        }
    }
    Ok(())
}

async fn health() -> Json<serde_json::Value> {
    Json(serde_json::json!({"status": "ok", "service": "forgecore"}))
}

async fn analyze(
    State(state): State<AppState>,
    Json(body): Json<InspectBody>,
) -> Result<Json<AnalysisReport>, (StatusCode, String)> {
    analyze_directory(body.root, &state.config)
        .map(Json)
        .map_err(|error| (StatusCode::BAD_REQUEST, error.to_string()))
}
